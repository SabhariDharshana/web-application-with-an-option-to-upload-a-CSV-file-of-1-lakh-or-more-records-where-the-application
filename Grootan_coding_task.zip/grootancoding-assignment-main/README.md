Create a web application with an option to upload a CSV file of 1 lakh or more records,where the application should read the records, process it, and push to the database table
